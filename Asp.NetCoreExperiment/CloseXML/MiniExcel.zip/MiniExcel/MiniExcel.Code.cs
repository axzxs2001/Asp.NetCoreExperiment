﻿namespace MiniExcelLibs
{
    using System;
    using System.Linq;

    public static partial class MiniExcel
    {
        public static string LISENCE_CODE = null;
    }
}
