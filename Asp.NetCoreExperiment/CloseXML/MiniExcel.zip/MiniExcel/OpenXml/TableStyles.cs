﻿namespace MiniExcelLibs.OpenXml
{
    public enum TableStyles
    {
        None,
        Default
    }
}