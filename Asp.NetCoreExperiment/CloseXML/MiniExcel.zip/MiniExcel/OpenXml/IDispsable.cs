﻿namespace MiniExcelLibs.OpenXml
{
    internal interface IDispsable
    {
    }
}